function setup() { // parenthesis hold what goes in the arguments.
  
  createCanvas(400,400); // sets the canvas size.
}



function draw() {// curly brackets hold chains of statement.
  background(255);// the background () function is what gives the background its color.
  ellipse (200, 200, 50, 50); // ellipse function is used to draw/make an ellipse

  
  
}
