/*
Created by Dawn C. Hayes March 2017. 
*/
modified by martin sanders

var circX; 
circX = 200; 
var circY;  
circY = 200; 
var circStroke = 125; 
var circR = 55; 
var circG = 38; 
var circB = 223; 
var circSize = 75;
canvBG = 125, 55, 255; 

var recX = 100;
var recY = 300;
var recStroke = 35;
var recCol = 0;
var recSize = 75;



function setup() {  
	createCanvas(400, 400); 
}


function draw() {
	background(canvBG); 
	stroke(circStroke); 
	fill(circR, circG, circB);  
	stroke(circStroke);  
	ellipse(circX, circY, circSize, circSize); 
	ellipse(circX + 50, circY - 75, circSize, circSize); // by adding + 50 and -75, the position of the ellipse is offset against the other.
	fill(circR, circG, circB, 135); 
	
	
    stroke(recStroke);
    fill(recCol);
    rect(recX, recY, recSize, recSize);
    
    recY = recY - 2; // use a - incrementor to make the rectangle appear to move up on the canvas.
    

}