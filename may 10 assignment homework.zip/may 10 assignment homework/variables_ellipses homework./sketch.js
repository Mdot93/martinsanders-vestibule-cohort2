/*
Example that uses variables instead of hard coded values.
created by Dawn C.Hayes March 2017.
modified by Martin Sanders May 2017.
*/
var circX;   // declare a variable. circle's x position would be circX.
circX = 200; // allocate a value to a variable. the name and value is intent by the maker. in this example the value would be 200.
var circY;   // name the circle's y variable.
circY = 300; // give a value to circleY. 
var circStroke = 130; // give a value to set the grayscale color for the circle's outline. 
var circR = 65; // a value to assign the r spot in an RGB set of arguments.
var circG = 110; // a value to appoint the g spot in an RGB set of arguments.
var circB = 232; // a value to appoint the b spot in an RGB set of arguments.
var circSize = 80; // a value for the circle's width and height. These are the last two arguments in the ellipse function.
canvBG = 125, 55, 255; // a variable can be named and have multiple values assigned when separated by commas. 

function setup() {  
	createCanvas(500, 400); 
}


function draw() {
	background(canvBG); // fill in the arguments with the variables. 
	stroke(circStroke); 
	fill(circR, circG, circB);  
	stroke(circStroke);  
	ellipse(circX, circY, circSize, circSize); 
	ellipse(circX + 50, circY - 75, circSize, circSize); 
	fill(circR, circG, circB, 135); 
  
}