
/* 
quad moves across
Created by Dawn C. Hayes March 2017. 
modified by Martin Sanders
*/

var quadX; 
quadX = 200; 
var quadY;  
quadY = 200; 
var quadStroke = 125; 
var quadR = 60; 
var quadG = 140; 
var quadB = 220; 
var quadSize = 80;
canvBG = 89, 128, 90; 

function setup() {  
	createCanvas(500, 400); 
}


function draw() {
	background(canvBG); 
	stroke(quadStroke); 
	fill(quadR, quadG, quadB);  
	stroke(quadStroke);  
	quad(quadX, quadY, quadSize, quadSize); 
	quad(quadX + 50, quadY - 75, quadSize, quadSize); 
	fill(quadR, quadG, quadB, 135); 
	
	quadX = quadX + 4; // in this line of code the draw loop(), the value of quadX will be increased  by 4.
					   

}
